
$(document).ready(function () {
  var lista = [];

 

  

 
});



// Matheus Soares de Lacerda